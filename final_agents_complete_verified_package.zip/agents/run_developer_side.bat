@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul

echo ======================================================
echo   Autonomous Developer Side Runner - Cline CLI YOLO
echo ======================================================
echo.

echo This runner creates a NEW project on your Desktop from one idea.
echo It uses Cline CLI in YOLO mode for zero-intervention automation.
echo.
set /p IDEA=What is your website/app project idea? 
if "%IDEA%"=="" (
  echo No idea entered. Exiting.
  pause
  exit /b 1
)

set "DESKTOP=%USERPROFILE%\Desktop"
set "STAMP=%DATE:/=-%_%TIME::=-%"
set "STAMP=%STAMP: =_%"
set "STAMP=%STAMP:.=-%"
set "PROJECT_ROOT=%DESKTOP%\autonomous_project_%STAMP%"
mkdir "%PROJECT_ROOT%" >nul 2>nul
mkdir "%PROJECT_ROOT%\agents" >nul 2>nul

xcopy "%~dp0*.md" "%PROJECT_ROOT%\agents\" /Y /Q >nul
copy "%~f0" "%PROJECT_ROOT%\agents\run_developer_side.bat" >nul
if exist "%~dp0run_buyer_client_side.bat" copy "%~dp0run_buyer_client_side.bat" "%PROJECT_ROOT%\agents\run_buyer_client_side.bat" >nul

> "%PROJECT_ROOT%\PROJECT_IDEA.md" echo # Project Idea
>> "%PROJECT_ROOT%\PROJECT_IDEA.md" echo.
>> "%PROJECT_ROOT%\PROJECT_IDEA.md" echo %IDEA%

> "%PROJECT_ROOT%\CLINE_DEVELOPER_TASK.md" echo You are running in Developer Side Mode.
>> "%PROJECT_ROOT%\CLINE_DEVELOPER_TASK.md" echo Read PROJECT_IDEA.md.
>> "%PROJECT_ROOT%\CLINE_DEVELOPER_TASK.md" echo Read all files in ./agents.
>> "%PROJECT_ROOT%\CLINE_DEVELOPER_TASK.md" echo Follow ./agents/.agent.md as the main orchestrator.
>> "%PROJECT_ROOT%\CLINE_DEVELOPER_TASK.md" echo Build the full project from the idea, using all specialist agents and supervisors.
>> "%PROJECT_ROOT%\CLINE_DEVELOPER_TASK.md" echo Work only inside this project folder.
>> "%PROJECT_ROOT%\CLINE_DEVELOPER_TASK.md" echo Run install, lint, typecheck, tests, browser/e2e checks where possible, fix issues, prepare buyer handoff, and create FINAL_SUPERVISOR_SIGNOFF.md.
>> "%PROJECT_ROOT%\CLINE_DEVELOPER_TASK.md" echo Never deploy to production or use paid services without explicit approval.

echo.
echo Project folder created:
echo %PROJECT_ROOT%
echo.

where code >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  start "" code "%PROJECT_ROOT%"
)

where cline >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
  echo Cline CLI was not found.
  echo Install/authenticate first:
  echo   npm install -g cline
  echo   cline auth
  echo.
  echo Then run this file again.
  pause
  exit /b 1
)

cd /d "%PROJECT_ROOT%"
echo Starting Cline in zero-intervention YOLO mode...
echo.
cline -y "Read CLINE_DEVELOPER_TASK.md and execute it completely."

echo.
echo Developer automation finished. Check the project folder and reports.
pause
endlocal
