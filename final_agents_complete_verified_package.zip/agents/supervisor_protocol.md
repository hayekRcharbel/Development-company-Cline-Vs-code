# Supervisor Protocol

Every specialist agent must have its work reviewed by its corresponding supervisor agent before the orchestrator moves to the next stage.

## Signoff Format
Each supervisor must create or append to `SUPERVISOR_REVIEW_LOG.md` using this format:

```md
## [Agent Name] Review
Status: PASS / PASS_WITH_NOTES / FAIL
Checked:
- Item 1
- Item 2
Findings:
- Finding 1
Required Fixes:
- Fix 1
Signoff:
- Approved by: [Supervisor Agent Name]
```

## Fail Handling
If a supervisor marks FAIL:
1. Send the findings back to the specialist agent.
2. The specialist fixes the issues.
3. Supervisor reviews again.
4. Continue until PASS or PASS_WITH_NOTES.

## Completion
The `supervisor_manager_agent.md` creates `FINAL_SUPERVISOR_SIGNOFF.md` after checking all reviews.


## Universal Safety Rules
- Work only inside the current project folder unless explicitly told otherwise by the runner.
- Never delete, overwrite, or modify files outside the allowed project/client folder.
- Never expose secrets, API keys, tokens, passwords, private keys, cookies, or credentials.
- Never hardcode secrets in source code. Use `.env` and `.env.example`.
- Never deploy to production, buy domains, spend money, or perform irreversible server actions without explicit owner approval.
- Prefer safe, reversible commands. Avoid destructive commands.
- Document every assumption and every requirement that cannot be completed automatically.
