# Agent Package Index

## Main Control
- `.agent.md` — main orchestrator
- `supervisor_protocol.md` — required review/signoff protocol
- `supervisor_manager_agent.md` — final signoff authority

## Developer-Side Agents
- `web_designer.md`
- `web_programmer.md`
- `web_auditor.md`
- `qa_qc_agent.md`
- `marketing_agent.md`
- `production_agent.md`
- `cline_commander_agent.md`

## Supervisor Agents
- `web_designer_supervisor_agent.md`
- `web_programmer_supervisor_agent.md`
- `web_auditor_supervisor_agent.md`
- `qa_qc_supervisor_agent.md`
- `marketing_supervisor_agent.md`
- `production_supervisor_agent.md`
- `cline_commander_supervisor_agent.md`
- `setup_supervisor_agent.md`
- `buyer_verification_supervisor_agent.md`

## Buyer / Client-Side Agents
- `setup_agent.md`
- `buyer_verification_manager_agent.md`

## Automation
- `run_developer_side.bat`
- `run_buyer_client_side.bat`
- `RUN_BAT_README.md`
