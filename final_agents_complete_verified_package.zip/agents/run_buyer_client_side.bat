@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul

echo ======================================================
echo   Buyer / Client Side Implementation Runner
 echo ======================================================
echo.
echo This runner is for implementing an ALREADY-BUILT bought project
echo on the client machine/server. It does NOT create a new project.
echo.
set /p PROJECT_PATH=Paste the full path of the delivered project folder, or press Enter to use this current folder: 
if "%PROJECT_PATH%"=="" set "PROJECT_PATH=%CD%"

if not exist "%PROJECT_PATH%" (
  echo Project path does not exist:
  echo %PROJECT_PATH%
  pause
  exit /b 1
)

mkdir "%PROJECT_PATH%\agents" >nul 2>nul
xcopy "%~dp0*.md" "%PROJECT_PATH%\agents\" /Y /Q >nul
copy "%~f0" "%PROJECT_PATH%\agents\run_buyer_client_side.bat" >nul
if exist "%~dp0run_developer_side.bat" copy "%~dp0run_developer_side.bat" "%PROJECT_PATH%\agents\run_developer_side.bat" >nul

> "%PROJECT_PATH%\CLINE_BUYER_IMPLEMENTATION_TASK.md" echo You are running in Buyer / Client Side Mode.
>> "%PROJECT_PATH%\CLINE_BUYER_IMPLEMENTATION_TASK.md" echo This is an already-built bought/delivered project. Do NOT create a new product from scratch.
>> "%PROJECT_PATH%\CLINE_BUYER_IMPLEMENTATION_TASK.md" echo Read ./agents/setup_agent.md and ./agents/buyer_verification_manager_agent.md.
>> "%PROJECT_PATH%\CLINE_BUYER_IMPLEMENTATION_TASK.md" echo Also use their supervisor agents and supervisor_protocol.md.
>> "%PROJECT_PATH%\CLINE_BUYER_IMPLEMENTATION_TASK.md" echo Implement the project on this client machine/server: inspect prerequisites, install dependencies, configure safe env defaults, run migrations if safe, start the app, verify local URL, verify network/server logistics where possible, fix safe local issues, and create BUYER_SETUP_REPORT.md plus BUYER_VERIFICATION_REPORT.md.
>> "%PROJECT_PATH%\CLINE_BUYER_IMPLEMENTATION_TASK.md" echo Ask only for required secrets, passwords, paid actions, production deployment approval, or impossible missing information.
>> "%PROJECT_PATH%\CLINE_BUYER_IMPLEMENTATION_TASK.md" echo Never expose secrets. Never perform irreversible production changes without approval.

where code >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  start "" code "%PROJECT_PATH%"
)

where cline >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
  echo Cline CLI was not found.
  echo Install/authenticate first:
  echo   npm install -g cline
  echo   cline auth
  echo.
  pause
  exit /b 1
)

cd /d "%PROJECT_PATH%"
echo Starting buyer/client implementation with Cline YOLO mode...
echo.
cline -y "Read CLINE_BUYER_IMPLEMENTATION_TASK.md and execute it completely."

echo.
echo Buyer/client implementation finished. Check BUYER_SETUP_REPORT.md and BUYER_VERIFICATION_REPORT.md.
pause
endlocal
