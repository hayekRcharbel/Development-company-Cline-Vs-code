# Final Autonomous Agents Package

Extract this ZIP to your Desktop so you have:

```text
Desktop/agents/
```

Run `run_developer_side.bat` to create a new project from one idea.
Run `run_buyer_client_side.bat` to implement an already-built project on a client machine/server.

See `agents/RUN_BAT_README.md` for details.
